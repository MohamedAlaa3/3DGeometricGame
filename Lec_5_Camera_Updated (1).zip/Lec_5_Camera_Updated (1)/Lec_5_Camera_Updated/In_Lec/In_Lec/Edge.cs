﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace In_Lec
{
    class Edge
    {
        public int i, j;
        public Color cl;

        public Edge(int ii, int jj)
        {
            i = ii;
            j = jj;
        }
    }
}
